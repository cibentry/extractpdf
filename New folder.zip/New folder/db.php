
<?php

$con=mysqli_connect('localhost','root','','certigo');
if($con->connect_error){
    die("connection failed".$con->connect_error);
}
echo ""
?>