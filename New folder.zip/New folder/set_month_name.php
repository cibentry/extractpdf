<?php
if (isset($_POST['monthName'])) {
    $monthName = $_POST['monthName'];
    // Now you can use the $monthName variable
}
?>